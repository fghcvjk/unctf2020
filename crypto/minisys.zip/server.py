import os, time, string, random
from Crypto.Cipher import AES
from Crypto.Util import Counter
from binascii import hexlify, unhexlify

banner = '''
    __  ____       _    _____            __
   /  |/  (_)___  (_)  / ___/__  _______/ /____  ____ ___
  / /|_/ / / __ \/ /   \__ \/ / / / ___/ __/ _ \/ __ `__ \\
 / /  / / / / / / /   ___/ / /_/ (__  ) /_/  __/ / / / / /
/_/  /_/_/_/ /_/_/   /____/\__, /____/\__/\___/_/ /_/ /_/
                          /____/
'''

flag = os.environ.get('FLAG')

class mini_system:
    def __init__(self):
        print(banner)
        self.key = os.urandom(16)
        self.salt = b''.join(bytes([random.choice(list(range(0x7c))+list(range(0x7d, 0x100)))]) for i in range(16))
        self.username_charset = string.digits + string.ascii_letters + "_@"

    def __check_username(self, username):
        for _ in username:
            if _ not in self.username_charset:
                return False
        if len(username) >= 12 or len(username) == 0 or username == "skr@minisys":
            return False
        else:
            return True

    def sign_up(self):
        self.r = time.localtime(time.time())[5]
        aes = AES.new(self.key, AES.MODE_CTR, counter=Counter.new(128, initial_value=self.r))
        username = input("> ")
        if not self.__check_username(username):
            print("[!] Invalid username!")
            exit(0)
        token = hexlify(aes.encrypt(username.encode() + b'|' + self.salt + b'|lv0')).decode()
        print("token={}".format(token))

    def sign_in(self):
        token = input("> ")
        try:
            ct = unhexlify(token)
            aes = AES.new(self.key, AES.MODE_CTR, counter=Counter.new(128, initial_value=self.r))
            pt = aes.decrypt(ct).split(b'|')
            assert(len(pt) == 3)
            username, salt, level = pt[0], pt[1], pt[2]
            if username == b'skr@minisys' and salt == self.salt and level == b"lv1":
                print(flag)
                exit(0)
            else:
                print("Nothing Here~")
        except:
            print("Nothing Here~")

    def option(self):
        print("[1] sign up | [2] sign in | [3] quit")
        opt = input("> ")
        if opt == "1":
            self.sign_up()
        elif opt == "2":
            self.sign_in()
        elif opt == "3":
            print("Bye~")
            exit(0)
        else:
            print("[!] Invalid option!")
    
    
def main():
    minisys = mini_system()
    while True:
        minisys.option()


if __name__ == '__main__':
    main()